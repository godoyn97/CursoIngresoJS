#include <stdio.h>
#include <stdlib.h>
#include "alta.h"

int menu(char texto[])
{
    int opcion;
    printf("%s\n1.Alta Producto\n2.Mostrar\n3.ordenar por descripcion\n5.Salir\n",texto);
    scanf("%d",&opcion);
    return opcion;
}
