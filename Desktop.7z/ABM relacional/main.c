#include <stdio.h>
#include <stdlib.h>
#define MED 5
#define CLI 10
#define LAB 3

int main()
{



    return 0;
}

