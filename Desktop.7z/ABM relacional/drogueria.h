typedef struct
{
    int dia;
    int mes;
    int anio;
}eFecha;

typedef struct
{
    int idMedicamento;
    char descripcion[50];
    float precio;
    int laboratorio;
    int stock;
    eFecha elaboracion;
    eFecha vencimiento;
//    int estado;

}eMedicamento;

typedef struct
{
    int idLaboratorio;
    char nombre[50];
    char direccion[50];
    char telefono[50];
}eLaboratorio;

typedef struct
{
    int idCliente;
    char nombreCliente[50];
    int medicamento;
}eCliente;

void inicializarMedicamentos(eMedicamento [], int);
void inicializarLaboratorio(eLaboratorio[],int);
void inicializarClientes(eCliente[],int);

