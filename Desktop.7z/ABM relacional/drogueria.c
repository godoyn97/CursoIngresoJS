#include <stdlib.h>
#include <stdio.h>
#include "drogueria.h"

void inicializarMedicamentos(eMedicamento lista[], int tam)
{
    int idMedicamento[]= {1,2,3,4,5};
    char descripcion[][50]= {"Valium","Ibuprofeno","Diclofenac","acito","aaaa"};
    float precio[]= {5,10,7,6,55};
    //char laboratorio[][30]= {"Bago","Bayer","Roemer","Roemer","Bago"};
    //int estado[]= {1,1,1,1,1};
    int stock[]={23,5,12,65,58};


    int i;

    for(i=0; i<tam; i++)
    {
        lista[i].codigo = codigo[i];
        lista[i].precio = precio[i];
        lista[i].estado = estado[i];
        strcpy(lista[i].descripcion,descripcion[i]);
        strcpy(lista[i].laboratorio,laboratorio[i]);
    }
}

void inicializarLaboratorio(eLaboratorio lista[],int)
{
    int idA[]= {5,4,3,2,1};
    //char descripcion[][50]= {"Valium","Ibuprofeno","Diclofenac","acito","aaaa"};
   // float precio[]= {5,10,7,6,55};
    char nombreA[][30]= {"Bago","Bayer","Roemer","Roemer","Bago"};
    //int estado[]= {1,1,1,1,1};
    char direccionA[][50]={"Av Mitre","Lisandro","Varela","Berazategui","Quilmes","Ezpeleta"};
    char telefonoA[][50]={"111111111","2222222","3333333","44444444","55555555"};


    int i;

    for(i=0; i<tam; i++)
    {
        lista[i].idLaboratorio = idA[i];

        strcpy(lista[i].nombre,nombreA[i]);
        strcpy(lista[i].direccion,direccionA[i]);
        strcpy(lista[i].telefono,telefonoA[i]);


    }
}
void inicializarClientes(eCliente[],int)
{
    int idClienteA[]={}

    int i;

    for(i=0; i<tam; i++)
    {
        lista[i].codigo = codigo[i];
        lista[i].precio = precio[i];
        lista[i].estado = estado[i];
        strcpy(lista[i].descripcion,descripcion[i]);
        strcpy(lista[i].laboratorio,laboratorio[i]);
    }
}

