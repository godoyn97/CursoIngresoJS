#include <stdio.h>
#include <stdlib.h>
typedef struct
{
int id;
char marca[20];
char modelo[15];
float precio;
}eNotebook;




int main()
{
    //printf("Hello world!\n");
    eNotebook *unaNotebook;
    unaNotebook= new_notebook();
    if(unaNotebook==NULL)
    {
        printf("no se pudo asignar memoria");
        exit(1);
    }
    unaNotebook->id=8;
    strcpy(unaNotebook->marca,"HP");
    srtcpy(unaNotebook->modelo,"envy");
    unaNotebook->precio=30000;

    return 0;
}


eNotebook* new_notebook()
{
    return (eNotebook*)malloc(sizeof(eNotebook));
}

void printNotebook(eNotebook*n)
{
    printf("id:%d modelo:%s marca:%s precio:%.2f",n->id, n->marca, n->modelo, n->precio);
}
