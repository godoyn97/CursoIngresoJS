
/** \brief muestra un menu de opciones de alta en consola
 * \param recibe una cadena de caracteres
 * \return un entero para elejir las opciones
 */
int menu(char[]);



