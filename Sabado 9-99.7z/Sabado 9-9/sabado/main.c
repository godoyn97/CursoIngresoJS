#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#define TAM 3




int main()
{
    int codigo[TAM]= {0}, auxInt;
    char descripcion[TAM][50],auxArray[100];//auxiliar mayor
    float precio[TAM],auxFloat;
    int stock[TAM];
    int opcion;
    int i;
    int j;

    do
    {
        opcion=menu("ingrese opcion");

        switch(opcion)
        {
        case 1:

            for(i=0; i<TAM; i++)
            {
                if(codigo[i]==0)
                {
                    printf("Ingrese codigo producto: \n");
                    scanf("%d",&codigo[i]);

                    printf("\nIngrese descripcion: ");
                    fflush(stdin);
                    gets(descripcion[i]);

                    printf("\nIngrese precio del producto: ");
                    scanf("%f",&precio[i]);

                    printf("\nIngrese stock del producto: ");
                    scanf("%d",&stock[i]);

                    break;
                }

            }
            break;
        case 2:
            for(i=0; i<TAM; i++)
            {
                if(codigo[i]!=0)
                {
                    printf("%d--%s--%d--$%2.f\n",codigo[i],descripcion[i],stock[i],precio[i]);
                }
            }
            break;

        case 3:
            for(i=0; i<TAM-1; i++)
            {
                for(j=i+1; j<TAM; j++)
                {
                    if(strcmp(descripcion[i],descripcion[j])>0)
                    {
                        auxArray[]=descripcion[i];  //falta strcpy
                        descripcion[i]=descripcion[j];
                        descripcion[j]=auxArray[];

                        auxInt=codigo[i];
                        codigo[j]=codigo[j];
                        codigo[j]=auxInt;

                        auxInt=precio[i];
                        precio[j]=precio[j];
                        precio[j]=auxInt;
                    }
                }
            }

        }


    }
    while(opcion!=5);
    return 0;
}





